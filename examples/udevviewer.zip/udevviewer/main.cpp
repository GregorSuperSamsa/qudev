#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "qudev_device_model.h"


int main(int argc, char** argv) {
    QGuiApplication app(argc, argv);
    qmlRegisterType<QudevDeviceModel>("Qudev.Demo", 1, 0, "QudevDeviceModel");

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/Main.qml")));

    if (engine.rootObjects().isEmpty()) {
        return 1;
    }

    return app.exec();
}
