#include "qudev_device_model.h"
#include <QVariantMap>

QudevDeviceModel::QudevDeviceModel(QObject* parent)
    : QAbstractListModel(parent)
{
    connect(&service_, &QudevService::enumerateFinished,
            this, &QudevDeviceModel::onEnumerateFinished);
    connect(&service_, &QudevService::deviceFound,
            this, &QudevDeviceModel::onDeviceFound);

    // keep QML property in sync if needed later:
    connect(&service_, &QudevService::filtersChanged,
            this, &QudevDeviceModel::filtersChanged);
}

int QudevDeviceModel::rowCount(const QModelIndex& parent) const {
    return parent.isValid() ? 0 : items_.size();
}

QVariant QudevDeviceModel::data(const QModelIndex& index, int role) const {
    if (!index.isValid() || index.row() < 0 || index.row() >= items_.size())
        return {};
    const QudevDevice& d = items_[index.row()];
    switch (role) {
    case DeviceMapRole: return toMap(d);
    case SyspathRole:   return d.syspath;
    case DevnodeRole:   return d.devnode;
    case SubsystemRole: return d.subsystem;
    case DevtypeRole:   return d.devtype;
    case SysnameRole:   return d.sysname;
    case DriverRole:    return d.driver;
    case MajorRole:     return static_cast<uint>(d.major);
    case MinorRole:     return static_cast<uint>(d.minor);
    case ActionRole:    return d.action;
    default:            return {};
    }
}

QHash<int, QByteArray> QudevDeviceModel::roleNames() const {
    return {
            { DeviceMapRole, "device" },
            { SyspathRole,   "syspath" },
            { DevnodeRole,   "devnode" },
            { SubsystemRole, "subsystem" },
            { DevtypeRole,   "devtype" },
            { SysnameRole,   "sysname" },
            { DriverRole,    "driver" },
            { MajorRole,     "major" },
            { MinorRole,     "minor" },
            { ActionRole,    "action" },
            };
}

void QudevDeviceModel::clear() {
    if (items_.isEmpty()) return;
    beginResetModel();
    items_.clear();
    endResetModel();
}

bool QudevDeviceModel::enumerate() {
    clear();
    return service_.enumerate();
}

bool QudevDeviceModel::startMonitoring() {
    return service_.startMonitoring();
}

void QudevDeviceModel::stopMonitoring() {
    service_.stopMonitoring();
}

void QudevDeviceModel::setFilters(const QVariantMap& m) {
    service_.setFilters(m);
    emit filtersChanged();
}

void QudevDeviceModel::onEnumerateFinished(QList<QudevDevice> devices) {
    if (devices.isEmpty()) return;
    beginInsertRows({}, 0, devices.size() - 1);
    items_.reserve(items_.size() + devices.size());
    for (auto& d : devices) items_.push_back(std::move(d));
    endInsertRows();
}

void QudevDeviceModel::onDeviceFound(const QudevDevice& d) {
    beginInsertRows({}, 0, 0);
    items_.push_front(d);
    endInsertRows();
}

QVariantMap QudevDeviceModel::toMap(const QudevDevice& d) {
    // If you already have d.toVariantMap(), just return that instead.
    QVariantMap m;
    m["syspath"]   = d.syspath;
    m["devnode"]   = d.devnode;
    m["subsystem"] = d.subsystem;
    m["devtype"]   = d.devtype;
    m["sysname"]   = d.sysname;
    m["driver"]    = d.driver;
    m["major"]     = static_cast<uint>(d.major);
    m["minor"]     = static_cast<uint>(d.minor);
    m["action"]    = d.action;
    return m;
}
