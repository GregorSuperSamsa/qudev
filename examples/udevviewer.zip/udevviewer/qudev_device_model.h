#pragma once
#include <QAbstractListModel>
#include <QVector>

#include "qudev_service.h"

/**
 * @brief List model exposing Qudev devices to QML.
 *
 * Owns a QudevService, subscribes to its signals, and presents rows with roles.
 * Provides thin pass-through methods to trigger enumerate/start/stop.
 */
class QudevDeviceModel : public QAbstractListModel {
    Q_OBJECT
    Q_PROPERTY(QVariantMap filters READ filters WRITE setFilters NOTIFY filtersChanged)
public:
    enum Roles {
        DeviceMapRole = Qt::UserRole + 1,
        SyspathRole, DevnodeRole, SubsystemRole, DevtypeRole, SysnameRole, DriverRole,
        MajorRole, MinorRole, ActionRole
    };
    Q_ENUM(Roles)

    explicit QudevDeviceModel(QObject* parent = nullptr);

    // QAbstractListModel
    int rowCount(const QModelIndex& parent = {}) const override;
    QVariant data(const QModelIndex& index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    // High-level API for QML
    Q_INVOKABLE void clear();
    Q_INVOKABLE bool enumerate();
    Q_INVOKABLE bool startMonitoring();
    Q_INVOKABLE void stopMonitoring();

    QVariantMap filters() const { return service_.filters(); }
    void setFilters(const QVariantMap& m);

signals:
    void filtersChanged();

private slots:
    void onEnumerateFinished(QList<QudevDevice> devices);
    void onDeviceFound(const QudevDevice& d);

private:
    static QVariantMap toMap(const QudevDevice& d);

private:
    QudevService        service_;
    QVector<QudevDevice> items_;
};
