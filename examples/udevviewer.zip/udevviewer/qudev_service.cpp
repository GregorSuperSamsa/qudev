#include "qudev_service.h"
#include <QVariant>
#include <QHash>

QudevService::QudevService(QObject* parent)
    : QObject(parent)
{
    // forward live monitor events to our own signal
    connect(&qudev_, &Qudev::deviceFound, this, &QudevService::deviceFound);
}

bool QudevService::enumerate()
{
    qudev_.setFilters(filters_);

    // Directly get the list of QudevDevice from the facade:
    const QList<QudevDevice> devices = qudev_.enumerate();

    // Emit the snapshot as-is to listeners (e.g., the model):
    emit enumerateFinished(devices);
    return true;
}

bool QudevService::startMonitoring()
{
    qudev_.setFilters(filters_);
    return qudev_.startMonitoring();
}

void QudevService::stopMonitoring()
{
    qudev_.stopMonitoring();
}

QVariantMap QudevService::filters() const
{
    return filtersMap_;
}

void QudevService::setFilters(const QVariantMap& m)
{
    if (filtersMap_ == m) return;
    filtersMap_ = m;
    filters_    = mapToFilters(m);
    emit filtersChanged();
}

// --- helpers ---

static QHash<QString, QString> toHash(const QVariantMap& m) {
    QHash<QString, QString> h;
    for (auto it = m.cbegin(); it != m.cend(); ++it) {
        h.insert(it.key(), it.value().toString());
    }
    return h;
}

QudevFilters QudevService::mapToFilters(const QVariantMap& m)
{
    QudevFilters f;
    f.subsystem     = m.value("subsystem").toString();
    f.devtype       = m.value("devtype").toString();
    f.sysname       = m.value("sysname").toString();
    f.devnode       = m.value("devnode").toString();
    f.syspathPrefix = m.value("syspathPrefix").toString();
    f.tags          = m.value("tags").toStringList();
    f.actions       = m.value("actions").toStringList();

    if (m.contains("properties"))      f.properties      = toHash(m.value("properties").toMap());
    if (m.contains("sysattrs"))        f.sysattrs        = toHash(m.value("sysattrs").toMap());
    if (m.contains("nomatchSysattrs")) f.nomatchSysattrs = toHash(m.value("nomatchSysattrs").toMap());
    return f;
}
