#pragma once
#include <QObject>
#include <QVariantMap>
#include <QList>

#include <qudev.h>
#include <qudev_device.h>
#include <qudev_filters.h>

/**
 * @brief Thin service that wraps the Qudev facade for QML/C++ consumers.
 *
 * - Holds a Qudev instance.
 * - Owns and applies filters (set from QML as QVariantMap).
 * - Provides enumerate() and start/stopMonitoring() entry points.
 * - Emits deviceFound() for live monitor events.
 * - Emits enumerateFinished() with the initial snapshot.
 */
class QudevService : public QObject {
    Q_OBJECT
    Q_PROPERTY(QVariantMap filters READ filters WRITE setFilters NOTIFY filtersChanged)
public:
    explicit QudevService(QObject* parent = nullptr);

    Q_INVOKABLE bool enumerate();        // one-shot snapshot (emits enumerateFinished)
    Q_INVOKABLE bool startMonitoring();  // live stream (emits deviceFound)
    Q_INVOKABLE void stopMonitoring();

    QVariantMap   filters() const;
    void          setFilters(const QVariantMap& m);

signals:
    void filtersChanged();
    void enumerateFinished(QList<QudevDevice> devices);
    void deviceFound(const QudevDevice& device);

private:
    static QudevFilters mapToFilters(const QVariantMap& m);

private:
    Qudev        qudev_;        // your public facade
    QudevFilters filters_;      // internal representation
    QVariantMap  filtersMap_;   // QML-facing mirror
};
